<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_parent_css' ) ):
    function chld_thm_cfg_parent_css() {
        wp_enqueue_style( 'chld_thm_cfg_parent', trailingslashit( get_template_directory_uri() ) . 'style.css', array( 'rgs' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'chld_thm_cfg_parent_css', 10 );

// END ENQUEUE PARENT ACTION


add_action('wp_logout','logout_redirect');

function logout_redirect(){

    wp_redirect( home_url() );
    
    exit;

}

add_filter( 'gettext', 'ld_custom_paypal_button_text', 20, 3 );
function ld_custom_paypal_button_text( $translated_text, $text, $domain ) {
	switch ( $translated_text ) {
		case 'Proceed to PayPal' :
			$translated_text = __( 'Buy or RSVP Now', 'woocommerce' );
			break;
	}
	return $translated_text;
}









add_action( 'after_setup_theme', 'tu_disable_wc_lightbox', 20 );
function tu_disable_wc_lightbox() {
    remove_theme_support( 'wc-product-gallery-lightbox' );
}
 function remove_image_zoom_support() {
    remove_theme_support( 'wc-product-gallery-zoom' );
}
add_action( 'wp', 'remove_image_zoom_support', 100 );




add_filter('woocommerce_checkout_get_value', function($input, $key) {
global $current_user;
// Return the user property if it exists, false otherwise
return ($current_user->$key
? $current_user->$key
: false
);
}, 10, 2);



/**
 * Redirect users after add to cart.
 */
function my_custom_add_to_cart_redirect( $url ) {

	$url = WC()->cart->get_checkout_url();
	// $url = wc_get_checkout_url(); // since WC 2.5.0

	return $url;

}
add_filter( 'woocommerce_add_to_cart_redirect', 'my_custom_add_to_cart_redirect' );



/* show element if user is logged into woocommerce */

add_action('wp_head', 'add_css_head');
function add_css_head() {
   if ( is_user_logged_in() ) {
   ?>
      <style>
          .sellertitle {
             display:block !important;     
           }
      </style>
   <?php
   } else {
   ?>
      <style>
          .sellertitle {
             display:none;     
           }
      </style>
   <?php
   }
}







/**
  * Edit my account menu order
  */

 function my_account_menu_order() {
 	$menuOrder = array(
 		'dashboard'          => __( 'Dashboard', 'woocommerce' ),
		'edit-account'    	=> __( 'Account Username and Password', 'woocommerce' ),
		'edit-address'       => __( 'Account Details', 'woocommerce' ),
 		'orders'             => __( 'Orders', 'woocommerce' ),
 		'downloads'          => __( 'Download', 'woocommerce' ),
 		'customer-logout'    => __( 'Logout', 'woocommerce' ),
 	);
 	return $menuOrder;
 }
 add_filter ( 'woocommerce_account_menu_items', 'my_account_menu_order' );






/* Woo checkout required fields */
add_filter( 'woocommerce_billing_fields', 'ts_require_wc_company_field');
function ts_require_wc_company_field( $fields ) {
$fields['billing_first_name']['required'] = true;
	$fields['billing_last_name']['required'] = true;
	$fields['billing_company']['required'] = true;
	$fields['billing_address_1']['required'] = true;
	$fields['billing_city']['required'] = true;
	$fields['billing_state']['required'] = true;
	$fields['billing_postcode']['required'] = true;
	$fields['billing_phone']['required'] = true;
	$fields['billing_email']['required'] = true;
return $fields;
}

